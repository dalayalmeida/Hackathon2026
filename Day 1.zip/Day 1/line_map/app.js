/*
 * Renders the Line 0 interactive map.
 * Coordinates: SVG x = KP. Origin at KP 0.
 * UP track at y = -40, DOWN track at y = +40.
 */

const SVG_NS = "http://www.w3.org/2000/svg";
const svg    = document.getElementById("map");
const Y_UP   = -40;
const Y_DOWN = 40;

const SECTION_BY_ID = {};
SECTIONS.forEach(s => SECTION_BY_ID[s.id] = s);
const SIGNAL_BY_ID = {};
SIGNALS.forEach(s => SIGNAL_BY_ID[s.id] = s);

function el(tag, attrs = {}, parent = svg) {
   const node = document.createElementNS(SVG_NS, tag);
   for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
   parent.appendChild(node);
   return node;
}

function tip(node, text) {
   node.classList.add("hoverable");
   node.addEventListener("mousemove", (ev) => {
      const t = document.getElementById("tooltip");
      t.textContent = text;
      t.style.left = (ev.pageX + 12) + "px";
      t.style.top  = (ev.pageY + 12) + "px";
      t.classList.add("shown");
   });
   node.addEventListener("mouseleave", () => {
      document.getElementById("tooltip").classList.remove("shown");
   });
}

/* -------------- Arrow markers (defs) -------------- */
{
   const defs = el("defs");
   const m1 = el("marker", {
      id: "arr-up", viewBox: "0 0 10 10",
      refX: 9, refY: 5, markerWidth: 8, markerHeight: 8, orient: "auto"
   }, defs);
   el("path", { d: "M 0 0 L 10 5 L 0 10 z", class: "arrow-marker" }, m1);
   const m2 = el("marker", {
      id: "arr-down", viewBox: "0 0 10 10",
      refX: 9, refY: 5, markerWidth: 8, markerHeight: 8, orient: "auto"
   }, defs);
   el("path", { d: "M 0 0 L 10 5 L 0 10 z", class: "arrow-marker-orange" }, m2);
}

/* -------------- Tracks (always drawn) -------------- */

el("line", { x1: 0,    y1: Y_UP,   x2: 1298, y2: Y_UP,   class: "track-up" });
el("line", { x1: 0,    y1: Y_DOWN, x2: 1298, y2: Y_DOWN, class: "track-down" });
el("line", { x1: -50, y1: Y_UP,   x2: 0,    y2: Y_UP,   class: "track-tail" });
el("line", { x1: 1248, y1: Y_UP,   x2: 1298, y2: Y_UP,   class: "track-tail" });
el("line", { x1: -50, y1: Y_DOWN, x2: 0,    y2: Y_DOWN, class: "track-tail" });
el("line", { x1: 1248, y1: Y_DOWN, x2: 1298, y2: Y_DOWN, class: "track-tail" });
el("line", { x1: -30, y1: Y_UP,   x2: -10, y2: Y_DOWN, class: "track-xover" });
el("line", { x1: -30, y1: Y_DOWN, x2: -10, y2: Y_UP,   class: "track-xover" });
el("line", { x1: 1278, y1: Y_UP,   x2: 1298, y2: Y_DOWN, class: "track-xover" });
el("line", { x1: 1278, y1: Y_DOWN, x2: 1298, y2: Y_UP,   class: "track-xover" });

/* -------------- Direction arrows -------------- */
{
   const gArr = el("g", { "data-cat": "arrows" });
   // Place a few arrow marks along each track
   [200, 700, 1200].forEach(kp => {
      const a = el("line", {
         x1: kp - 20, y1: Y_UP, x2: kp, y2: Y_UP,
         stroke: "#1e4b82", "stroke-width": 0.001,
         "marker-end": "url(#arr-up)"
      }, gArr);
      const b = el("line", {
         x1: kp + 20, y1: Y_DOWN, x2: kp, y2: Y_DOWN,
         stroke: "#e1821e", "stroke-width": 0.001,
         "marker-end": "url(#arr-down)"
      }, gArr);
   });
}

/* -------------- KP ruler -------------- */
{
   const g = el("g", { "data-cat": "ruler" });
   const major = [-50, 0, 162, 212, 542, 592, 920, 970, 1198, 1248, 1298];
   const tickY = Y_DOWN + 55;
   el("line", { x1: -50, y1: tickY, x2: 1298, y2: tickY, class: "ruler-line" }, g);
   major.forEach(kp => {
      el("line", { x1: kp, y1: tickY - 3, x2: kp, y2: tickY + 3, class: "ruler-line" }, g);
      const t = el("text", { x: kp, y: tickY + 13, class: "ruler-text" }, g);
      t.textContent = "KP " + kp;
   });
}

/* -------------- Stations -------------- */
STATIONS.forEach(st => {
   const cx = (st.kpStart + st.kpEnd) / 2;
   // platform rectangles tied to platform section visibility
   el("rect", {
      x: st.kpStart, y: Y_UP - 10, width: st.kpEnd - st.kpStart, height: 20,
      class: "platform-up", "data-cat": "sec-up-plat"
   });
   el("rect", {
      x: st.kpStart, y: Y_DOWN - 10, width: st.kpEnd - st.kpStart, height: 20,
      class: "platform-down", "data-cat": "sec-down-plat"
   });
   const tName = el("text", { x: cx, y: -75, class: "station-name", "data-cat": "station-name" });
   tName.textContent = st.name;
   const tCode = el("text", { x: cx, y: -65, class: "station-code", "data-cat": "station-name" });
   tCode.textContent = "(" + st.id + ")";
   const tKp = el("text", { x: cx, y: 85, class: "station-kp", "data-cat": "station-kp" });
   tKp.textContent = "KP " + st.kpStart + " - " + st.kpEnd;
});

/* -------------- Track sections (rect overlays + label) -------------- */
SECTIONS.forEach(sec => {
   let cat = "sec-up-run";
   if (sec.kind === "PLATFORM" && sec.track === "UP")    cat = "sec-up-plat";
   if (sec.kind === "PLATFORM" && sec.track === "DOWN")  cat = "sec-down-plat";
   if (sec.kind === "RUNNING"  && sec.track === "UP")    cat = "sec-up-run";
   if (sec.kind === "RUNNING"  && sec.track === "DOWN")  cat = "sec-down-run";
   if (sec.kind === "TAIL")                              cat = "sec-tail";
   if (sec.kind === "CROSSOVER")                         cat = "sec-xover";

   const y = sec.track === "UP" ? Y_UP - 12 :
             sec.track === "DOWN" ? Y_DOWN - 12 : -5;
   const yh = sec.track === "XOVER" ? 10 : 24;
   const rectClass = sec.track === "UP"   ? "section-rect-up"
                   : sec.track === "DOWN" ? "section-rect-down"
                   : sec.kind  === "TAIL" ? "section-rect-tail"
                   : "section-rect-xover";
   const rect = el("rect", {
      x: sec.kpStart, y: y, width: sec.kpEnd - sec.kpStart, height: yh,
      class: rectClass, "data-cat": cat
   });
   tip(rect, sec.id + " (KP " + sec.kpStart + " to " + sec.kpEnd + ")");
   const cx = (sec.kpStart + sec.kpEnd) / 2;
   const labelY = sec.track === "UP" ? Y_UP - 16 :
                  sec.track === "DOWN" ? Y_DOWN + 22 :
                  -2;
   const label = el("text", {
      x: cx, y: labelY, class: "section-label", "data-cat": cat
   });
   label.textContent = sec.id;
});

/* -------------- Switches -------------- */
SWITCHES.forEach(sw => {
   const cy = sw.track === "UP" ? Y_UP : Y_DOWN;
   const c = el("circle", {
      cx: sw.kp, cy: cy, r: 4,
      class: "switch-marker", "data-cat": "switch"
   });
   tip(c, sw.id + " (KP " + sw.kp + ", track " + sw.track + ")");
   const t = el("text", {
      x: sw.kp, y: cy + (sw.track === "UP" ? -8 : 14),
      class: "switch-label", "data-cat": "switch"
   });
   t.textContent = sw.id;
});

/* -------------- Signals -------------- */
SIGNALS.forEach(sig => {
   const isUp = sig.track === "UP";
   const cy = isUp ? Y_UP - 8 : Y_DOWN + 8;
   const cls = isUp ? "signal-marker-up" : "signal-marker-down";
   const dir = isUp ? 1 : -1;
   const t = el("polygon", {
      points: [
         (sig.kp - 3) + "," + cy,
         (sig.kp + 3) + "," + cy,
         sig.kp + "," + (cy + dir * 5)
      ].join(" "),
      class: cls, "data-cat": "signal"
   });
   tip(t, sig.id + " (KP " + sig.kp + ", governs " + sig.governs + ")");
   const lbl = el("text", {
      x: sig.kp, y: isUp ? cy - 6 : cy + 11,
      class: "signal-label", "data-cat": "signal"
   });
   lbl.textContent = sig.id;
});

/* -------------- Balises -------------- */
BALISES.forEach(bal => {
   const cy = bal.track === "UP" ? Y_UP + 11 : Y_DOWN - 11;
   const c = el("circle", {
      cx: bal.kp, cy: cy, r: 2.2,
      class: "balise-marker", "data-cat": "balise"
   });
   tip(c, bal.id + " (KP " + bal.kp + ")");
});

/* -------------- Routes (Day 2) -------------- */
ROUTES.forEach(r => {
   const sec = SECTION_BY_ID[r.sections[0]];
   if (!sec) return;
   const cat = r.direction === "UP" ? "route-up" : "route-down";
   const y = r.direction === "UP" ? Y_UP : Y_DOWN;
   // route highlight: a thick semi-transparent line along the locked section
   const line = el("line", {
      x1: sec.kpStart, y1: y, x2: sec.kpEnd, y2: y,
      class: "route-overlay", "data-cat": cat
   });
   tip(line, r.id + " (locks " + r.sections.join(", ") + ")");
   const cx = (sec.kpStart + sec.kpEnd) / 2;
   const labelY = r.direction === "UP" ? y + 22 : y - 17;
   const label = el("text", {
      x: cx, y: labelY, class: "route-label", "data-cat": cat
   });
   label.textContent = r.id;
});

/* -------------- Trains -------------- */
TRAINS.forEach(tr => {
   const isUp = tr.track === "UP";
   const cy = isUp ? Y_UP : Y_DOWN;
   const rearKp = isUp ? tr.kp - tr.length : tr.kp + tr.length;
   const x1 = Math.min(tr.kp, rearKp);
   const x2 = Math.max(tr.kp, rearKp);
   const rect = el("rect", {
      x: x1, y: cy - 7, width: x2 - x1, height: 14,
      rx: 2, class: "train-body", "data-cat": "train"
   });
   tip(rect, tr.id + " head at KP " + tr.kp + " (" + tr.track + ", in " + tr.section + ")");
   const lbl = el("text", {
      x: (x1 + x2) / 2, y: cy + 3, class: "train-label", "data-cat": "train"
   });
   lbl.textContent = tr.id;
   // info text
   const infoY = isUp ? cy - 22 : cy + 28;
   const info = el("text", {
      x: (x1 + x2) / 2, y: infoY,
      class: "train-info-text", "data-cat": "train-info"
   });
   info.textContent = "mode " + tr.initialMode + " - LMA " + tr.initialLMA +
                      " - speed " + tr.initialSpeed;
});

/* -------------- Build bottom panels -------------- */

(function buildTimetable() {
   const tbody = document.querySelector("#timetable-table tbody");
   TIMETABLE.slice().sort((a, b) => a.time - b.time || a.train.localeCompare(b.train))
      .forEach(entry => {
         const tr = document.createElement("tr");
         tr.innerHTML = `<td>${entry.time}</td><td>${entry.train}</td><td><code>${entry.route}</code></td>`;
         tbody.appendChild(tr);
      });
})();

(function buildConstants() {
   const root = document.getElementById("constants-content");
   for (const [section, items] of Object.entries(CONSTANTS)) {
      const h = document.createElement("h4");
      h.textContent = section;
      root.appendChild(h);
      const dl = document.createElement("dl");
      for (const [k, v] of Object.entries(items)) {
         const dt = document.createElement("dt");
         dt.textContent = k;
         const dd = document.createElement("dd");
         dd.textContent = v;
         dl.appendChild(dt);
         dl.appendChild(dd);
      }
      root.appendChild(dl);
   }
})();

/* -------------- Checkbox handling -------------- */

function applyCategory(cat, on) {
   document.querySelectorAll('[data-cat="' + cat + '"]').forEach(node => {
      if (on) node.classList.remove("hidden");
      else    node.classList.add("hidden");
   });
}

document.querySelectorAll(".sidebar input[type=checkbox][data-cat]").forEach(cb => {
   applyCategory(cb.dataset.cat, cb.checked);
   cb.addEventListener("change", () => applyCategory(cb.dataset.cat, cb.checked));
});

// Bottom-panel checkboxes (timetable + constants)
function toggleBottom(id, panelId) {
   const cb = document.getElementById(id);
   const panel = document.getElementById(panelId);
   function apply() {
      if (cb.checked) panel.classList.remove("hidden");
      else            panel.classList.add("hidden");
   }
   apply();
   cb.addEventListener("change", apply);
}
toggleBottom("show-timetable", "timetable-panel");
toggleBottom("show-constants", "constants-panel");

document.getElementById("check-all").addEventListener("click", () => {
   document.querySelectorAll(".sidebar input[type=checkbox]").forEach(cb => {
      cb.checked = true;
      cb.dispatchEvent(new Event("change"));
   });
});

document.getElementById("uncheck-all").addEventListener("click", () => {
   document.querySelectorAll(".sidebar input[type=checkbox]").forEach(cb => {
      cb.checked = false;
      cb.dispatchEvent(new Event("change"));
   });
});
