/* All the Line 0 infrastructure as JS objects.
   Identical to the numbers used in the B machines. */

const STATIONS = [
   { id: "NS", name: "Natal Shopping", kpStart: 0,    kpEnd: 50   },
   { id: "VD", name: "Via Direta",     kpStart: 162,  kpEnd: 212  },
   { id: "FL", name: "Floca",          kpStart: 542,  kpEnd: 592  },
   { id: "NP", name: "Nuplan",         kpStart: 920,  kpEnd: 970  },
   { id: "RT", name: "Reitoria UFRN",  kpStart: 1198, kpEnd: 1248 },
];

const SECTIONS = [
   { id: "TS_TAIL_NS_U", track: "UP",    kpStart: -50,  kpEnd: 0,    kind: "TAIL",      station: "S_NS"   },
   { id: "TS_NS_U",      track: "UP",    kpStart: 0,    kpEnd: 50,   kind: "PLATFORM",  station: "S_NS"   },
   { id: "TS_NS_VD_U",   track: "UP",    kpStart: 50,   kpEnd: 162,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_VD_U",      track: "UP",    kpStart: 162,  kpEnd: 212,  kind: "PLATFORM",  station: "S_VD"   },
   { id: "TS_VD_FL_U",   track: "UP",    kpStart: 212,  kpEnd: 542,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_FL_U",      track: "UP",    kpStart: 542,  kpEnd: 592,  kind: "PLATFORM",  station: "S_FL"   },
   { id: "TS_FL_NP_U",   track: "UP",    kpStart: 592,  kpEnd: 920,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_NP_U",      track: "UP",    kpStart: 920,  kpEnd: 970,  kind: "PLATFORM",  station: "S_NP"   },
   { id: "TS_NP_RT_U",   track: "UP",    kpStart: 970,  kpEnd: 1198, kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_RT_U",      track: "UP",    kpStart: 1198, kpEnd: 1248, kind: "PLATFORM",  station: "S_RT"   },
   { id: "TS_TAIL_RT_U", track: "UP",    kpStart: 1248, kpEnd: 1298, kind: "TAIL",      station: "S_RT"   },
   { id: "TS_TAIL_RT_D", track: "DOWN",  kpStart: 1248, kpEnd: 1298, kind: "TAIL",      station: "S_RT"   },
   { id: "TS_RT_D",      track: "DOWN",  kpStart: 1198, kpEnd: 1248, kind: "PLATFORM",  station: "S_RT"   },
   { id: "TS_NP_RT_D",   track: "DOWN",  kpStart: 970,  kpEnd: 1198, kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_NP_D",      track: "DOWN",  kpStart: 920,  kpEnd: 970,  kind: "PLATFORM",  station: "S_NP"   },
   { id: "TS_FL_NP_D",   track: "DOWN",  kpStart: 592,  kpEnd: 920,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_FL_D",      track: "DOWN",  kpStart: 542,  kpEnd: 592,  kind: "PLATFORM",  station: "S_FL"   },
   { id: "TS_VD_FL_D",   track: "DOWN",  kpStart: 212,  kpEnd: 542,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_VD_D",      track: "DOWN",  kpStart: 162,  kpEnd: 212,  kind: "PLATFORM",  station: "S_VD"   },
   { id: "TS_NS_VD_D",   track: "DOWN",  kpStart: 50,   kpEnd: 162,  kind: "RUNNING",   station: "S_NONE" },
   { id: "TS_NS_D",      track: "DOWN",  kpStart: 0,    kpEnd: 50,   kind: "PLATFORM",  station: "S_NS"   },
   { id: "TS_TAIL_NS_D", track: "DOWN",  kpStart: -50,  kpEnd: 0,    kind: "TAIL",      station: "S_NS"   },
   { id: "TS_XO_NS",     track: "XOVER", kpStart: -30,  kpEnd: -10,  kind: "CROSSOVER", station: "S_NS"   },
   { id: "TS_XO_RT",     track: "XOVER", kpStart: 1278, kpEnd: 1298, kind: "CROSSOVER", station: "S_RT"   },
];

const SWITCHES = [
   { id: "P_NS_U", track: "UP",   kp: -10   },
   { id: "P_NS_D", track: "DOWN", kp: -10   },
   { id: "P_RT_U", track: "UP",   kp: 1278  },
   { id: "P_RT_D", track: "DOWN", kp: 1278  },
];

const SIGNALS = [
   { id: "SIG_NS_U", track: "UP",   kp: 50,   governs: "TS_NS_VD_U"   },
   { id: "SIG_VD_U", track: "UP",   kp: 212,  governs: "TS_VD_FL_U"   },
   { id: "SIG_FL_U", track: "UP",   kp: 592,  governs: "TS_FL_NP_U"   },
   { id: "SIG_NP_U", track: "UP",   kp: 970,  governs: "TS_NP_RT_U"   },
   { id: "SIG_RT_U", track: "UP",   kp: 1248, governs: "TS_TAIL_RT_U" },
   { id: "SIG_RT_D", track: "DOWN", kp: 1198, governs: "TS_NP_RT_D"   },
   { id: "SIG_NP_D", track: "DOWN", kp: 920,  governs: "TS_FL_NP_D"   },
   { id: "SIG_FL_D", track: "DOWN", kp: 542,  governs: "TS_VD_FL_D"   },
   { id: "SIG_VD_D", track: "DOWN", kp: 162,  governs: "TS_NS_VD_D"   },
   { id: "SIG_NS_D", track: "DOWN", kp: 0,    governs: "TS_TAIL_NS_D" },
];

const BALISES = [
   { id: "BAL_NS_ENTRY_U",   track: "UP",   kp: 5    },
   { id: "BAL_NS_EXIT_U",    track: "UP",   kp: 45   },
   { id: "BAL_NS_VD_MID_U",  track: "UP",   kp: 106  },
   { id: "BAL_VD_ENTRY_U",   track: "UP",   kp: 167  },
   { id: "BAL_VD_FL_MID_U",  track: "UP",   kp: 377  },
   { id: "BAL_FL_ENTRY_U",   track: "UP",   kp: 547  },
   { id: "BAL_FL_NP_MID_U",  track: "UP",   kp: 756  },
   { id: "BAL_NP_ENTRY_U",   track: "UP",   kp: 925  },
   { id: "BAL_NP_RT_MID_U",  track: "UP",   kp: 1084 },
   { id: "BAL_RT_ENTRY_U",   track: "UP",   kp: 1203 },
   { id: "BAL_RT_ENTRY_D",   track: "DOWN", kp: 1243 },
   { id: "BAL_NP_RT_MID_D",  track: "DOWN", kp: 1084 },
   { id: "BAL_NP_ENTRY_D",   track: "DOWN", kp: 965  },
   { id: "BAL_FL_NP_MID_D",  track: "DOWN", kp: 756  },
   { id: "BAL_FL_ENTRY_D",   track: "DOWN", kp: 587  },
   { id: "BAL_VD_FL_MID_D",  track: "DOWN", kp: 377  },
   { id: "BAL_VD_ENTRY_D",   track: "DOWN", kp: 207  },
   { id: "BAL_NS_VD_MID_D",  track: "DOWN", kp: 106  },
   { id: "BAL_NS_ENTRY_D",   track: "DOWN", kp: 45   },
   { id: "BAL_NS_EXIT_D",    track: "DOWN", kp: 5    },
];

const TRAINS = [
   { id: "T01", kp: 25,   track: "UP",   section: "TS_NS_U",
     length: 50, initialMode: "SBY", initialLMA: 25,  initialSpeed: 0 },
   { id: "T02", kp: 1223, track: "DOWN", section: "TS_RT_D",
     length: 50, initialMode: "SBY", initialLMA: 1223, initialSpeed: 0 },
];

/* Day 2: the eight running routes (origin signal, destination signal,
   list of sections each route locks). */
const ROUTES = [
   { id: "R_NS_VD_U", origin: "SIG_NS_U", destination: "SIG_VD_U",
     sections: ["TS_NS_VD_U"], direction: "UP" },
   { id: "R_VD_FL_U", origin: "SIG_VD_U", destination: "SIG_FL_U",
     sections: ["TS_VD_FL_U"], direction: "UP" },
   { id: "R_FL_NP_U", origin: "SIG_FL_U", destination: "SIG_NP_U",
     sections: ["TS_FL_NP_U"], direction: "UP" },
   { id: "R_NP_RT_U", origin: "SIG_NP_U", destination: "SIG_RT_U",
     sections: ["TS_NP_RT_U"], direction: "UP" },
   { id: "R_RT_NP_D", origin: "SIG_RT_D", destination: "SIG_NP_D",
     sections: ["TS_NP_RT_D"], direction: "DOWN" },
   { id: "R_NP_FL_D", origin: "SIG_NP_D", destination: "SIG_FL_D",
     sections: ["TS_FL_NP_D"], direction: "DOWN" },
   { id: "R_FL_VD_D", origin: "SIG_FL_D", destination: "SIG_VD_D",
     sections: ["TS_VD_FL_D"], direction: "DOWN" },
   { id: "R_VD_NS_D", origin: "SIG_VD_D", destination: "SIG_NS_D",
     sections: ["TS_NS_VD_D"], direction: "DOWN" },
];

/* Day 5: the timetable, eight scheduled dispatches. */
const TIMETABLE = [
   { time: 0,   train: "T01", route: "R_NS_VD_U" },
   { time: 0,   train: "T02", route: "R_RT_NP_D" },
   { time: 60,  train: "T01", route: "R_VD_FL_U" },
   { time: 60,  train: "T02", route: "R_NP_FL_D" },
   { time: 130, train: "T01", route: "R_FL_NP_U" },
   { time: 130, train: "T02", route: "R_FL_VD_D" },
   { time: 200, train: "T01", route: "R_NP_RT_U" },
   { time: 200, train: "T02", route: "R_VD_NS_D" },
];

/* Days 3, 4, 5: the key constants used by the machines. */
const CONSTANTS = {
   "Day 3 ZC": {
      "TRAIN_LENGTH": "50 m",
      "KP_MIN":       "-50 (south tail end)",
      "KP_MAX":       "1298 (north tail end)",
   },
   "Day 4 ATP": {
      "T_CYC_MS":         "200 ms (cycle time)",
      "T_EB_REACT_MS":    "500 ms (brake reaction)",
      "B_EB_CMSS":        "130 cm/s² = 1.3 m/s² (emergency brake rate)",
      "V_MAX_DMS":        "167 dm/s = 60 km/h (line speed)",
      "DELTA_X_0_M":      "2 m (position confidence after a balise)",
      "DELTA_V_DMS":      "3 dm/s (speed confidence)",
      "D_GEB_MARGIN_M":   "5 m (safety margin)",
      "THIS_TRAIN":       "T01 (modelled train)",
   },
   "Day 5 ATS": {
      "T_END":            "280 s (operational window)",
      "timetable":        "8 entries, 4 per train, at t = 0, 60, 130, 200",
   },
};

const KP_MIN = -50;
const KP_MAX = 1298;
